from django.shortcuts import render
from django.http import HttpResponse

from .models import Strength
from .models import Format
from .models import Dose
from .models import Length
from .models import Drug
import random



# Create your views here.

#def index(request):
    #return HttpResponse("Hello, world. You're at the pharmacy quiz index.")

def home(request):
    return HttpResponse("Hello, you are at the pharmacy quiz homepage.")

def score(request):
    return HttpResponse("Hello, you are at the score page.")

def question(request):
    #total_drugs = model.Drug.object.count()
    #debug = ""
    total_drugs = Drug.objects.all().count()
    random_index = int(random.random()*total_drugs)+1
    random_drug = Drug.objects.get(pk = random_index)

    random_field = random.choice([Drug.length, Drug.strength, Drug.format, Drug.dose])
    #random_field = Drug.format

    if random_field == Drug.strength:

            strength_excluding_correct = Strength.objects.exclude(strength = random_drug.strength)
            total_strength = strength_excluding_correct.count()
            random_index = int(random.random()*total_strength)
            random_strength = strength_excluding_correct[random_index]

            #new_prescription = [random_drug.name, random_drug.dose, random_drug.format, random_strength, random_drug.length]

            new_prescription = {
            'name': random_drug.name,
            'dose': random_drug.dose,
            'format': random_drug.format,
            'length': random_drug.length,
            'strength': random_strength,
            }
            errorField ="strength"

    elif random_field == Drug.format:

            format_excluding_correct = Format.objects.exclude(format = random_drug.format)
            total_format = format_excluding_correct.count()
            random_index = int(random.random()*total_format)
            if random_index < format_excluding_correct.count():
                random_format = format_excluding_correct[random_index]
            else:
                random_format = 'error'


            #new_prescription = [random_drug.name, random_drug.dose, random_format, random_drug.strength, random_drug.length]

            new_prescription = {
            'name': random_drug.name,
            'dose': random_drug.dose,
            'format': random_format,
            'length': random_drug.length,
            'strength': random_drug.strength
            }

            errorField ="format"
            #debug = str(random_index) + ", " + str(format_excluding_correct.count()) + ", " + str(random_index < format_excluding_correct.count())

    elif random_field == Drug.length:

            length_excluding_correct = Length.objects.all().exclude(length = random_drug.length)
            total_length = length_excluding_correct.count()
            random_index = int(random.random()*total_length) #random.randint(0, total_length - 1)
            random_length = length_excluding_correct[random_index]

            new_prescription = {
            'name': random_drug.name,
            'dose': random_drug.dose,
            'format': random_drug.format,
            'length': random_length,
            'strength': random_drug.strength
            }

            errorField ="length"

    else:
            doses_excluding_correct = Dose.objects.exclude(dose = random_drug.dose)
            total_doses = doses_excluding_correct.count()
            random_index = int(random.random()*total_doses)
            random_dose = doses_excluding_correct[random_index]

            #new_prescription = [random_drug.name, random_dose, random_drug.format, random_drug.length, random_drug.strength]

            new_prescription = {
            'name': random_drug.name,
            'dose': random_dose,
            'format': random_drug.format,
            'length': random_drug.length,
            'strength': random_drug.strength,
            }

            errorField ="dose"




    template = 'quiz/home.html'
    context = {'random_drug' : random_drug, 'new_prescription' : new_prescription, 'errorField' : errorField}
    return render(request, template, context)


