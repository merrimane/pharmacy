from django.contrib import admin

# Register your models here.

from .models import Strength
from .models import Format
from .models import Length
from .models import Dose
from .models import Drug



admin.site.register(Strength)
admin.site.register(Format)
admin.site.register(Length)
admin.site.register(Dose)
admin.site.register(Drug)