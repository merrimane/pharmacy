from django.db import models

# Create your models here.

# Create your models here.
#Strength is for the strength of the drug (i.e. 50mcg)
class Strength(models.Model):
    strength = models.CharField(max_length=20, default=None, unique=True)
    def __str__(self):
        return self.strength

#Drug_Format is for the format that the drug is available in (i.e. tablet)
class Format(models.Model):
    format = models.CharField(max_length=20, default=None, unique=True)
    def __str__(self):
        return self.format

#Drug_length is for the amount of time the drug is prescribed (i.e. 30 days)
class Length (models.Model):
    length = models.CharField(max_length=20, default=None, unique=True)

    def __str__(self):
        return self.length

#Dose is for the number of times the drug should be taken (i.e. once a day, twice a day)
class Dose (models.Model):
    dose = models.TextField(default=None, unique=True)
    strength = models.ManyToManyField(Strength, through='Drug', through_fields=('dose', 'strength'),)
    format = models.ManyToManyField (Format, through= 'Drug', through_fields=('dose', 'format'),)
    length = models.ManyToManyField (Length, through='Drug', through_fields=('dose', 'length'),)

    def __str__(self):
        return self.dose

#Drug is for the name of the drug iteself, which can come in many strengths, formats, length of prescription and doses
class Drug (models.Model):
    name = models.CharField(max_length=50, default=None)
    dose = models.ForeignKey(Dose, on_delete=models.CASCADE)
    strength = models.ForeignKey(Strength, on_delete=models.CASCADE)
    format = models.ForeignKey(Format, on_delete=models.CASCADE)
    length = models.ForeignKey(Length, on_delete=models.CASCADE)

    #objects = models.Manager() #The default manager

    def __str__(self):
       return self.name

#class PrescriptionManager(models.Manager):
	#def object(self, name, dose, strength, format, length):
		#return self.object.random.choice()




